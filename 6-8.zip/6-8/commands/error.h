//Error - ���� ����� ��� � ��, ������ error. ��. ��.h
#pragma once
#include"../node/node.h"
#include"../functions/functions.h"


struct cError : command {
	cError() {
		count = 1;
		is_user_command = false;
	}
	void execute(Node* node, std::vector<std::string> params) const override {
		if (node->node_type == COMPUTE_NODE) {
			std::string msg;
			msg += "error ";
			msg += params[0];
			node->parent.SendMsg(msg);
		}
		else {
			std::cout << "error : ";
			print_without_underscores(std::cout, params[0]);
			std::cout << std::endl;
		}
	}

	void man(std::ostream& out) const override {
		out << "error : \'error <string> \'";
	}
};