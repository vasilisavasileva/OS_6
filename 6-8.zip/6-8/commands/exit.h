//������������� ��� �������
#pragma once
#include"../node/node.h"

struct cExit : command {
	cExit() {
		count = 0;
		is_user_command = true;
	}
	void execute(Node* node, std::vector<std::string> params) const override {
		node->Exit();
		if (node->childs.size()) {
			auto it = node->childs.begin();
			for (; it != node->childs.end();++it) {
				//std::cout << "Sending exit...\n";
				if (it->SendMsg("exit")) {
					//std::cout << "Sended\n";
				}
				else {
					//std::cout << "Sending error\n";
				}
			}
		}
	}

	void man(std::ostream& out) const override {
		out << "exit : \'exit\'";
	}
};