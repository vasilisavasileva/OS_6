#include"../node/node.h"
#include<iostream>
#include<string>

int main(int argc, char* argv[]) {
	int id = std::atoi(argv[1]);
	std::cout << "[ID : " << id << " ]\n";
	int port_push = std::atoi(argv[2]);
	int port_pull = std::atoi(argv[3]);
	//std::cout << "Push " << port_push << std::endl << "Pull " << port_pull << std::endl;
	Node node(id, port_push, port_pull);
	return 0;
}