#include"node_menedger.h"
#include<cmath>
#include<iostream>

int NodeMenedger::findHeadList(int i) {
	bool is_found = false;
	int cur = 0;
	for (auto list : table) {
		for (auto el : list) {
			if (el == i) {
				is_found = true;
				break;
			}
		}
		if (is_found) {
			return cur;
		}
		++cur;
	}
	return NOT_FOUND;
}

int NodeMenedger::findHeadListAndInsert(int i, int n) {
	bool is_found = false;
	int cur = 0;
	for (auto list = table.begin(); list != table.end(); ++list) {
		for (auto el = list->begin(); el != list->end(); ++el) {
			if (*el == i) {
				is_found = true;
				++el;
				list->insert(el, n);
				break;
			}
		}
		if (is_found) {
			return cur;
		}
		++cur;
	}
	return NOT_FOUND;
}

void NodeMenedger::addList(int i) {
	table.push_back(std::list<int>());
	table.back().push_back(i);
}

void NodeMenedger::del(int i) {
	bool is_found = false;
	int cur = 0;
	for (auto list = table.begin(); list != table.end();++list) {
		list->remove(i);
		if (list->empty()) {
			last_deleted_list = cur;
		}
		++cur;
	}
	std::list<int> l;
	l.clear();
	table.remove(l);
}

void NodeMenedger::Graph() {
	std::cout << '('<<-1<<')' << std::endl;
	for (auto list : table) {
		std::cout << " |\n +";
		for (auto el : list) {
			std::cout <<"----"<< el;
		}
		std::cout << std::endl;
	}
}