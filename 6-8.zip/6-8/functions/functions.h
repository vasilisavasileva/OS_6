#pragma once
#include<string>
#include<algorithm>
#include<vector>
#include<iostream>
inline bool space(char c);

inline bool notspace(char c);

std::vector<std::string> split(const std::string& s);

void print_without_underscores(std::ostream& out, const std::string& str);